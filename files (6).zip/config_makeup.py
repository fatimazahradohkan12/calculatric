# -*- coding: utf-8 -*-
"""
Configuration des sites maquillage.

Beautymarket.ma et Zwine.ma tournent sur Shopify : on utilise leur API
JSON native de recherche (search/suggest.json), beaucoup plus fiable
qu'un scraping HTML classique.

Lhmiza.ma et BeautyMall.ma tournent sur WooCommerce : on s'appuie sur
les classes CSS que WooCommerce ajoute lui-même par défaut (li.product,
span.price...), qui sont beaucoup plus stables que des classes de thème
car ajoutées par le plugin WooCommerce, pas par le design du site.
"""

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    ),
    "Accept-Language": "fr-FR,fr;q=0.9,en;q=0.8",
}

REQUEST_TIMEOUT = 15
MAX_PAGES_PAR_SITE = 3

MAKEUP_SITES = {
    "beautymarket": {
        "nom_affiche": "Beautymarket.ma",
        "platform": "shopify",
        "base_url": "https://beautymarket.ma",
        # API JSON native de recherche Shopify (utilisée par la barre de
        # recherche du site) -> beaucoup plus fiable que du scraping HTML.
        "suggest_url": (
            "https://beautymarket.ma/search/suggest.json"
            "?q={query}&resources[type]=product&resources[limit]=20"
        ),
    },
    "zwine": {
        "nom_affiche": "Zwine.ma",
        "platform": "shopify",
        "base_url": "https://zwine.ma",
        "suggest_url": (
            "https://zwine.ma/search/suggest.json"
            "?q={query}&resources[type]=product&resources[limit]=20"
        ),
    },
    "lhmiza": {
        "nom_affiche": "Lhmiza.ma",
        "platform": "woocommerce",
        "base_url": "https://lhmiza.ma",
        "search_url": "https://lhmiza.ma/?s={query}&post_type=product&paged={page}",
        "selectors": {
            "product_card": "li.product",
            "link": "a",
            "name": ".woocommerce-loop-product__title, h2, h3",
            "price": "span.price",
        },
    },
    "beautymall": {
        "nom_affiche": "BeautyMall.ma",
        "platform": "woocommerce",
        "base_url": "https://beautymall.ma",
        "search_url": "https://beautymall.ma/?s={query}&post_type=product&paged={page}",
        "selectors": {
            "product_card": "li.product",
            "link": "a",
            "name": ".woocommerce-loop-product__title, h2, h3",
            "price": "span.price",
        },
    },
}
