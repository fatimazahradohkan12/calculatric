# Scraper Maroc — Vêtements & Maquillage

Petit outil avec interface graphique qui cherche un produit sur 8 sites
marocains (4 vêtements + 4 maquillage), filtre par fourchette de prix,
et sort une liste (tableau + CSV) avec nom du produit, prix et lien direct.

**Vêtements** : Jumia · Decathlon · Marjane Mall · Zara
**Maquillage** : Beautymarket.ma · Zwine.ma · Lhmiza.ma · BeautyMall.ma

Un menu dans l'interface graphique permet de basculer entre les deux
catégories.

## Installation

```bash
cd scraper_maroc
python3 -m venv venv
source venv/bin/activate        # sous Windows : venv\Scripts\activate
pip install -r requirements.txt
```

Tu as besoin de **Google Chrome** installé sur ta machine (pour Selenium,
utilisé sur Zara et en secours sur Decathlon/Marjane Mall). `webdriver-manager`
télécharge automatiquement le bon chromedriver, pas besoin de le faire à la main.

## Utilisation — Interface graphique (recommandé)

```bash
python gui.py
```

Une fenêtre s'ouvre avec :
- un champ pour le mot-clé produit (ex: `t-shirt homme`, `robe femme`, `jean slim`)
- deux champs prix min / prix max en MAD
- un bouton **🔍 Rechercher**
- un tableau des résultats trié par prix, avec le nom du site, le prix et le lien
- **double-clique une ligne** pour ouvrir le produit dans ton navigateur
- un bouton **Exporter en CSV** pour sauvegarder les résultats

La recherche tourne en arrière-plan (thread séparé) donc la fenêtre ne
se fige pas pendant que ça scrape — ça peut prendre 20-40 secondes à
cause de Zara et Selenium.

Tkinter est inclus avec Python, aucune installation supplémentaire n'est
nécessaire pour l'interface (juste les dépendances de `requirements.txt`).

## Utilisation — Terminal (alternative)

```bash
python scraper.py
```

Même logique mais en ligne de commande : le script te demande le
mot-clé et les prix min/max, puis affiche un tableau et exporte
`resultats.csv`.

## Structure du projet

- `config.py` — URLs de recherche et sélecteurs CSS par site (à ajuster
  si un site change son design, voir ci-dessous)
- `utils.py` — parsing de prix, dédoublonnage, export CSV
- `scraper.py` — logique de scraping + script principal

## ⚠️ Si un site ne renvoie plus de résultats

Les sites e-commerce changent régulièrement leur HTML. Si `jumia` ou
`decathlon` renvoie 0 résultat :

1. Ouvre l'URL de recherche du site dans Chrome
2. Clic droit sur le nom d'un produit → **Inspecter**
3. Repère la classe CSS (ex: `class="name"`)
4. Va dans `config.py`, section du site concerné, et corrige `selectors`

Pour **Zara** et **Marjane Mall**, il y a un filet de sécurité intégré :
si les sélecteurs CSS ne trouvent rien, le script bascule automatiquement
sur une extraction générique (tous les liens contenant un prix détecté
par regex). C'est moins précis mais plus résistant aux changements de design.

## Notes importantes

- **Zara** est une application React (SPA) avec une protection anti-bot
  assez stricte. Le scraping peut être lent, incomplet, ou bloqué selon
  les moments. Si Selenium ne renvoie rien, le plus simple reste
  d'ouvrir manuellement `https://www.zara.com/ma/fr/search?searchTerm=...`
- Les 4 sites **maquillage** (Beautymarket, Zwine, Lhmiza, BeautyMall)
  sont bâtis sur Shopify/WooCommerce, deux plateformes standard — le
  scraping y est donc plus stable et ne nécessite pas Selenium.
  Beautymarket et Zwine utilisent l'API JSON native de recherche
  Shopify (`/search/suggest.json`), avec un filet de sécurité HTML si
  jamais elle est désactivée sur le thème.
- Le script respecte un délai entre les requêtes (`time.sleep`) pour ne
  pas surcharger les serveurs — merci de ne pas le réduire à zéro.
- Usage strictement personnel : vérifie les CGU de chaque site avant un
  usage intensif ou commercial du scraping.

## ⚠️ Transparence sur les tests

Je n'ai pas d'accès réseau direct vers ces sites marocains depuis mon
environnement d'exécution : la structure de chaque site a été vérifiée
via des recherches web (pages réellement consultées, prix et URLs
réels), mais je n'ai pas pu exécuter le scraper en conditions réelles
avant de te le livrer. Si un site ne remonte rien, dis-le moi — je peux
corriger les sélecteurs avec toi.
