# -*- coding: utf-8 -*-
"""
Configuration centralisée : URLs de recherche + sélecteurs CSS par site.

Si un site change son design et que le scraper ne trouve plus rien,
c'est ICI qu'il faut regarder en premier. Pour retrouver les bons
sélecteurs : ouvre la page dans Chrome -> clic droit sur un prix ou un
nom de produit -> "Inspecter" -> repère la classe CSS -> remplace la
valeur correspondante ci-dessous.
"""

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    ),
    "Accept-Language": "fr-FR,fr;q=0.9,en;q=0.8",
}

REQUEST_TIMEOUT = 15  # secondes
MAX_PAGES_PAR_SITE = 3  # augmente si tu veux scraper plus de pages/résultats

SITES = {
    "jumia": {
        "nom_affiche": "Jumia Maroc",
        "search_url": "https://www.jumia.ma/catalog/?q={query}&sort=lowest-price&page={page}",
        "mode": "requests",  # site rendu côté serveur -> requests + BeautifulSoup suffit
        "selectors": {
            "product_card": "article.prd",
            "link": "a.core",          # href relatif, on ajoute le domaine
            "name": "h3.name",
            "price": "div.prc",
        },
        "base_url": "https://www.jumia.ma",
    },
    "decathlon": {
        "nom_affiche": "Decathlon Maroc",
        "search_url": "https://www.decathlon.ma/recherche?controller=search&s={query}&page={page}",
        "mode": "requests_with_selenium_fallback",
        "selectors": {
            "product_card": "div.product-container, article.product-miniature, div.js-product-miniature",
            "link": "h3 a, h5 a, a.product-thumbnail, a.thumbnail",
            "name": "h3, h5, a.product-thumbnail",
            "price": "span.price, span.product-price, .price",
        },
        "base_url": "https://www.decathlon.ma",
    },
    "marjanemall": {
        "nom_affiche": "Marjane Mall",
        "search_url": "https://www.marjanemall.ma/catalogsearch/result/?q={query}&p={page}",
        "mode": "requests_with_selenium_fallback",
        "selectors": {
            "product_card": "li.product-item, div.product-item-info",
            "link": "a.product-item-link",
            "name": "a.product-item-link",
            "price": "span.price",
        },
        "base_url": "https://www.marjanemall.ma",
    },
    "zara": {
        "nom_affiche": "Zara Maroc",
        # Zara n'a pas de recherche mot-clé simple stable par pays -> on scrape
        # une page de catégorie donnée (ex: t-shirts homme). Remplace l'URL
        # ci-dessous par la catégorie qui t'intéresse sur zara.com/ma/fr/
        "search_url": "https://www.zara.com/ma/fr/search?searchTerm={query}",
        "mode": "selenium",  # SPA React -> Selenium obligatoire
        "selectors": {
            "product_card": "li.product-grid-product, div.product-grid-product",
            "link": "a",
            "name": "img",  # souvent le nom est dans l'attribut alt de l'image
            "price": "span.money-amount__main, span.price",
        },
        "base_url": "https://www.zara.com",
    },
}
