# -*- coding: utf-8 -*-
"""
Scraper de maquillage sur 4 sites marocains :
Beautymarket.ma, Zwine.ma (Shopify) + Lhmiza.ma, BeautyMall.ma (WooCommerce)
"""

import time
import requests
from bs4 import BeautifulSoup
from urllib.parse import quote_plus

from config_makeup import MAKEUP_SITES, HEADERS, REQUEST_TIMEOUT, MAX_PAGES_PAR_SITE
from utils import extract_current_price, dedupe_results, filter_by_price


# ---------------------------------------------------------------------------
# SHOPIFY : API JSON native de recherche (search/suggest.json)
# ---------------------------------------------------------------------------

def scrape_shopify_site(site_key, keyword):
    cfg = MAKEUP_SITES[site_key]
    results = []
    url = cfg["suggest_url"].format(query=quote_plus(keyword))

    try:
        resp = requests.get(url, headers=HEADERS, timeout=REQUEST_TIMEOUT)
        resp.raise_for_status()
        data = resp.json()
        products = (
            data.get("resources", {})
            .get("results", {})
            .get("products", [])
        )
    except (requests.RequestException, ValueError) as e:
        print(f"  [!] {cfg['nom_affiche']} : erreur API ({e})")
        products = None

    if products:
        for p in products:
            nom = p.get("title", "").strip()
            href = p.get("url", "")
            if href.startswith("/"):
                href = cfg["base_url"] + href

            # Le champ "price" renvoyé par Shopify peut être un nombre déjà
            # formaté (ex: "119.00" ou "119,00 MAD" selon la config de la
            # boutique) -> on passe par notre parseur générique pour être sûr.
            prix_brut = str(p.get("price", ""))
            prix = extract_current_price(prix_brut + " MAD") if prix_brut else None

            if prix is None and prix_brut:
                try:
                    prix = float(prix_brut.replace(",", "."))
                except ValueError:
                    prix = None

            if nom and prix and href:
                results.append({
                    "site": cfg["nom_affiche"],
                    "nom": nom,
                    "prix": prix,
                    "lien": href,
                })

    # Filet de sécurité : si l'API JSON est vide/désactivée sur ce thème,
    # on retombe sur la page de recherche HTML classique de Shopify.
    if not results:
        results = _scrape_shopify_html_fallback(cfg, keyword)

    return results


def _scrape_shopify_html_fallback(cfg, keyword):
    """
    Filet de sécurité générique pour Shopify : cherche tous les liens
    /products/... sur la page de recherche HTML et extrait le prix le
    plus proche dans le texte environnant.
    """
    results = []
    url = f"{cfg['base_url']}/search?q={quote_plus(keyword)}&type=product"
    try:
        resp = requests.get(url, headers=HEADERS, timeout=REQUEST_TIMEOUT)
        resp.raise_for_status()
    except requests.RequestException as e:
        print(f"  [!] {cfg['nom_affiche']} (fallback HTML) : erreur réseau ({e})")
        return results

    soup = BeautifulSoup(resp.text, "html.parser")
    seen_hrefs = set()

    for a in soup.select('a[href*="/products/"]'):
        href = a.get("href", "").split("?")[0]
        if href in seen_hrefs:
            continue

        # Le prix et le nom sont généralement dans le conteneur parent
        container = a.find_parent(["li", "div"]) or a
        texte = container.get_text(" ", strip=True)
        prix = extract_current_price(texte)
        if not prix:
            continue

        nom = a.get_text(strip=True) or a.get("title", "") or texte[:60]
        if href.startswith("/"):
            href = cfg["base_url"] + href

        seen_hrefs.add(a.get("href", "").split("?")[0])
        results.append({
            "site": cfg["nom_affiche"],
            "nom": nom,
            "prix": prix,
            "lien": href,
        })

    return results


# ---------------------------------------------------------------------------
# WOOCOMMERCE : classes CSS core (li.product / span.price), très stables
# ---------------------------------------------------------------------------

def scrape_woocommerce_site(site_key, keyword, max_pages=MAX_PAGES_PAR_SITE):
    cfg = MAKEUP_SITES[site_key]
    sel = cfg["selectors"]
    results = []

    for page in range(1, max_pages + 1):
        url = cfg["search_url"].format(query=quote_plus(keyword), page=page)
        try:
            resp = requests.get(url, headers=HEADERS, timeout=REQUEST_TIMEOUT)
            resp.raise_for_status()
        except requests.RequestException as e:
            print(f"  [!] {cfg['nom_affiche']} page {page} : erreur réseau ({e})")
            break

        soup = BeautifulSoup(resp.text, "html.parser")
        cards = soup.select(sel["product_card"])
        if not cards:
            break

        for card in cards:
            name_el = card.select_one(sel["name"])
            price_el = card.select_one(sel["price"])
            link_el = card.select_one(sel["link"])

            if not (name_el and price_el and link_el):
                continue

            href = link_el.get("href", "")
            if href.startswith("/"):
                href = cfg["base_url"] + href

            nom = name_el.get_text(strip=True)
            prix = extract_current_price(price_el.get_text(" ", strip=True))

            if nom and prix and href:
                results.append({
                    "site": cfg["nom_affiche"],
                    "nom": nom,
                    "prix": prix,
                    "lien": href,
                })

        time.sleep(1)

    return results


# ---------------------------------------------------------------------------
# ORCHESTRATION
# ---------------------------------------------------------------------------

def scrape_all_makeup(keyword, prix_min, prix_max):
    all_results = []

    print(f"\n💄 Recherche de '{keyword}' entre {prix_min} et {prix_max} MAD...\n")

    print("→ Beautymarket.ma...")
    all_results += scrape_shopify_site("beautymarket", keyword)

    print("→ Zwine.ma...")
    all_results += scrape_shopify_site("zwine", keyword)

    print("→ Lhmiza.ma...")
    all_results += scrape_woocommerce_site("lhmiza", keyword)

    print("→ BeautyMall.ma...")
    all_results += scrape_woocommerce_site("beautymall", keyword)

    all_results = dedupe_results(all_results)
    filtered = filter_by_price(all_results, prix_min, prix_max)
    return filtered
