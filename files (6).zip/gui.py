# -*- coding: utf-8 -*-
"""
Interface graphique (Tkinter) unifiée : Vêtements + Maquillage.

Lancement :
    python gui.py
"""

import threading
import webbrowser
import tkinter as tk
from tkinter import ttk, messagebox

from scraper import scrape_all as scrape_all_clothes
from scraper_makeup import scrape_all_makeup
from utils import export_csv


MODES = {
    "vetements": {
        "label": "👕 Vêtements",
        "sites": "Jumia · Decathlon · Marjane Mall · Zara",
        "placeholder": "t-shirt homme, robe femme, jean slim...",
        "scrape_fn": scrape_all_clothes,
    },
    "maquillage": {
        "label": "💄 Maquillage",
        "sites": "Beautymarket · Zwine · Lhmiza · BeautyMall",
        "placeholder": "rouge à lèvres, mascara, fond de teint...",
        "scrape_fn": scrape_all_makeup,
    },
}


class ScraperGUI(tk.Tk):
    def __init__(self):
        super().__init__()

        self.title("Scraper Maroc — Vêtements & Maquillage")
        self.geometry("1000x640")
        self.minsize(860, 520)

        self.mode = tk.StringVar(value="vetements")
        self.results = []
        self._build_widgets()

    # ------------------------------------------------------------------ UI
    def _build_widgets(self):
        pad = {"padx": 8, "pady": 8}

        # --- Sélecteur de catégorie ---
        mode_frame = ttk.Frame(self)
        mode_frame.pack(fill="x", **pad)

        ttk.Label(mode_frame, text="Catégorie :", font=("", 10, "bold")).pack(side="left", padx=(0, 10))
        for key, cfg in MODES.items():
            ttk.Radiobutton(
                mode_frame, text=cfg["label"], value=key, variable=self.mode,
                command=self._on_mode_change
            ).pack(side="left", padx=(0, 15))

        self.sites_var = tk.StringVar(value=f"Sites : {MODES['vetements']['sites']}")
        ttk.Label(mode_frame, textvariable=self.sites_var, foreground="gray").pack(side="left", padx=(20, 0))

        # --- Barre de recherche ---
        top = ttk.Frame(self)
        top.pack(fill="x", **pad)

        ttk.Label(top, text="Produit :").grid(row=0, column=0, sticky="w")
        self.keyword_var = tk.StringVar(value="t-shirt homme")
        self.keyword_entry = ttk.Entry(top, textvariable=self.keyword_var, width=32)
        self.keyword_entry.grid(row=0, column=1, padx=(0, 20))

        ttk.Label(top, text="Prix min (MAD) :").grid(row=0, column=2, sticky="w")
        self.min_var = tk.StringVar(value="0")
        ttk.Entry(top, textvariable=self.min_var, width=10).grid(row=0, column=3, padx=(0, 20))

        ttk.Label(top, text="Prix max (MAD) :").grid(row=0, column=4, sticky="w")
        self.max_var = tk.StringVar(value="500")
        ttk.Entry(top, textvariable=self.max_var, width=10).grid(row=0, column=5, padx=(0, 20))

        self.search_btn = ttk.Button(top, text="🔍 Rechercher", command=self.on_search)
        self.search_btn.grid(row=0, column=6, padx=(10, 0))

        # --- Barre de statut / progression ---
        status_frame = ttk.Frame(self)
        status_frame.pack(fill="x", padx=8)

        self.status_var = tk.StringVar(value="Prêt.")
        ttk.Label(status_frame, textvariable=self.status_var, foreground="gray").pack(side="left")

        self.progress = ttk.Progressbar(status_frame, mode="indeterminate")
        self.progress.pack(side="right", fill="x", expand=True, padx=(20, 0))

        # --- Tableau de résultats ---
        table_frame = ttk.Frame(self)
        table_frame.pack(fill="both", expand=True, **pad)

        columns = ("site", "nom", "prix", "lien")
        self.tree = ttk.Treeview(table_frame, columns=columns, show="headings", selectmode="browse")
        self.tree.heading("site", text="Site")
        self.tree.heading("nom", text="Nom du produit")
        self.tree.heading("prix", text="Prix (MAD)")
        self.tree.heading("lien", text="Lien")

        self.tree.column("site", width=120, anchor="w")
        self.tree.column("nom", width=400, anchor="w")
        self.tree.column("prix", width=90, anchor="e")
        self.tree.column("lien", width=350, anchor="w")

        vsb = ttk.Scrollbar(table_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")

        self.tree.bind("<Double-1>", self.on_double_click)

        # --- Bas de fenêtre ---
        bottom = ttk.Frame(self)
        bottom.pack(fill="x", **pad)

        self.count_var = tk.StringVar(value="")
        ttk.Label(bottom, textvariable=self.count_var).pack(side="left")

        ttk.Button(bottom, text="Exporter en CSV", command=self.on_export).pack(side="right")
        ttk.Label(bottom, text="Double-clique une ligne pour ouvrir le lien dans le navigateur",
                  foreground="gray").pack(side="right", padx=(0, 20))

    # -------------------------------------------------------------- events
    def _on_mode_change(self):
        cfg = MODES[self.mode.get()]
        self.sites_var.set(f"Sites : {cfg['sites']}")
        self.keyword_var.set(cfg["placeholder"])
        self.tree.delete(*self.tree.get_children())
        self.results = []
        self.count_var.set("")
        self.status_var.set("Prêt.")

    def on_search(self):
        mode_cfg = MODES[self.mode.get()]
        keyword = self.keyword_var.get().strip()
        try:
            prix_min = float(self.min_var.get().replace(",", "."))
            prix_max = float(self.max_var.get().replace(",", "."))
        except ValueError:
            messagebox.showerror("Erreur", "Les prix min/max doivent être des nombres.")
            return

        if not keyword:
            messagebox.showerror("Erreur", "Merci de saisir un mot-clé produit.")
            return

        if prix_min > prix_max:
            prix_min, prix_max = prix_max, prix_min

        self.tree.delete(*self.tree.get_children())
        self.results = []
        self.count_var.set("")
        self.search_btn.config(state="disabled")
        self.progress.start(12)
        self.status_var.set(
            f"Recherche de « {keyword} » ({mode_cfg['label']}) entre {prix_min:.0f} et {prix_max:.0f} MAD..."
        )

        thread = threading.Thread(
            target=self._run_scraping,
            args=(mode_cfg["scrape_fn"], keyword, prix_min, prix_max),
            daemon=True,
        )
        thread.start()

    def _run_scraping(self, scrape_fn, keyword, prix_min, prix_max):
        try:
            results = scrape_fn(keyword, prix_min, prix_max)
            error = None
        except Exception as e:
            results = []
            error = str(e)

        self.after(0, self._on_scraping_done, results, error)

    def _on_scraping_done(self, results, error):
        self.progress.stop()
        self.search_btn.config(state="normal")

        if error:
            self.status_var.set("Erreur pendant le scraping.")
            messagebox.showerror("Erreur", f"Une erreur est survenue :\n{error}")
            return

        self.results = sorted(results, key=lambda r: r["prix"])
        for r in self.results:
            self.tree.insert("", "end", values=(r["site"], r["nom"], f"{r['prix']:.2f}", r["lien"]))

        if self.results:
            self.status_var.set("Recherche terminée.")
            self.count_var.set(f"{len(self.results)} produit(s) trouvé(s)")
        else:
            self.status_var.set("Recherche terminée : aucun résultat dans cette fourchette de prix.")
            self.count_var.set("0 produit trouvé")

    def on_double_click(self, event):
        item = self.tree.selection()
        if not item:
            return
        values = self.tree.item(item[0], "values")
        if len(values) >= 4:
            webbrowser.open(values[3])

    def on_export(self):
        if not self.results:
            messagebox.showinfo("Export", "Aucun résultat à exporter pour l'instant.")
            return
        path = export_csv(self.results)
        messagebox.showinfo("Export réussi", f"Résultats exportés dans :\n{path}")


if __name__ == "__main__":
    app = ScraperGUI()
    app.mainloop()
