# -*- coding: utf-8 -*-
"""Fonctions utilitaires partagées par tous les scrapers."""

import re
import csv

# Capture des nombres suivis OU précédés d'une devise :
#   "78.00 Dhs" / "1 299,00 MAD"  (suffixe - Jumia, Zwine, Beautymarket...)
#   "DH 273,00"                   (préfixe - Lhmiza)
#   "د.م.121.25"                  (préfixe arabe - BeautyMall)
PRICE_REGEX = re.compile(
    r"(\d[\d\s]*[.,]?\d*)\s*(?:MAD|Dhs|DH)"
    r"|(?:MAD|DH|Dhs|د\.م\.)\s*(\d[\d\s]*[.,]?\d*)",
    re.IGNORECASE,
)


def parse_price(text):
    """
    Extrait le premier prix trouvé dans un texte et le renvoie en float (MAD).
    Renvoie None si aucun prix n'est détecté.
    Gère les formats "169,00 MAD", "88.00 Dhs", "1 299 DH", etc.
    """
    if not text:
        return None
    match = PRICE_REGEX.search(text)
    if not match:
        return None
    raw = (match.group(1) or match.group(2) or "").replace(" ", "").replace("\xa0", "")
    # Le séparateur décimal peut être une virgule ou un point
    if "," in raw and "." in raw:
        raw = raw.replace(".", "").replace(",", ".")
    elif "," in raw:
        raw = raw.replace(",", ".")
    try:
        return float(raw)
    except ValueError:
        return None


def extract_current_price(text):
    """
    Extrait le prix RÉELLEMENT payé (pas le prix barré) à partir d'un
    texte pouvant contenir plusieurs prix, ex :
      - "Prix soldé 460.00 dh Prix habituel 500.00 dh"  -> 460.00
      - "DH 340,00 Le prix initial était : DH 340,00. DH 273,00Le prix actuel est : DH 273,00."
                                                          -> 273.00
      - "Prix habituel 140.00 dh 119.00 dh" (barré + actuel, sans label) -> 119.00 (dernier trouvé)
      - "45.00 dh" (pas de promo) -> 45.00
    """
    if not text:
        return None

    lower = text.lower()

    # Cas 1 : label explicite "prix soldé" / "prix actuel" -> ce prix est le bon
    for label in ["prix soldé", "prix actuel", "le prix actuel"]:
        idx = lower.find(label)
        if idx != -1:
            after = text[idx:idx + 60]
            match = PRICE_REGEX.search(after)
            if match:
                return parse_price(match.group(0))

    # Cas 2 : plusieurs prix mais aucun label -> le dernier prix mentionné
    # est généralement le prix final après réduction
    all_prices = [parse_price(m.group(0)) for m in PRICE_REGEX.finditer(text)]
    all_prices = [p for p in all_prices if p is not None]
    if all_prices:
        return all_prices[-1]

    return None


def dedupe_results(results):
    """Supprime les doublons en se basant sur le lien du produit."""
    seen = set()
    out = []
    for r in results:
        if r["lien"] not in seen:
            seen.add(r["lien"])
            out.append(r)
    return out


def filter_by_price(results, prix_min, prix_max):
    return [
        r for r in results
        if r["prix"] is not None and prix_min <= r["prix"] <= prix_max
    ]


def export_csv(results, path="resultats.csv"):
    with open(path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=["site", "nom", "prix", "lien"])
        writer.writeheader()
        for r in results:
            writer.writerow(r)
    return path


def print_results_table(results):
    if not results:
        print("\nAucun résultat trouvé dans cette fourchette de prix.\n")
        return
    print(f"\n{'Site':<14}{'Prix (MAD)':<12}{'Nom du produit':<55}Lien")
    print("-" * 130)
    for r in sorted(results, key=lambda x: x["prix"]):
        nom = (r["nom"][:52] + "...") if len(r["nom"]) > 52 else r["nom"]
        print(f"{r['site']:<14}{r['prix']:<12.2f}{nom:<55}{r['lien']}")
    print(f"\nTotal : {len(results)} produit(s) trouvé(s).\n")
