# -*- coding: utf-8 -*-
"""
Scraper de vêtements sur 4 sites marocains : Jumia, Decathlon, Marjane Mall, Zara.

Utilisation :
    python scraper.py

Le script te demande un mot-clé (ex: "t-shirt homme") et une fourchette
de prix en MAD, puis scrape les 4 sites et affiche/exporte les résultats
qui rentrent dans ta fourchette de prix.

Dépendances : voir requirements.txt
"""

import time
import sys
import requests
from bs4 import BeautifulSoup
from urllib.parse import quote_plus

from config import SITES, HEADERS, REQUEST_TIMEOUT, MAX_PAGES_PAR_SITE
from utils import parse_price, dedupe_results, filter_by_price, export_csv, print_results_table


# ---------------------------------------------------------------------------
# SCRAPING VIA REQUESTS + BEAUTIFULSOUP (sites rendus côté serveur)
# ---------------------------------------------------------------------------

def scrape_site_requests(site_key, keyword, max_pages=MAX_PAGES_PAR_SITE):
    cfg = SITES[site_key]
    sel = cfg["selectors"]
    results = []

    for page in range(1, max_pages + 1):
        url = cfg["search_url"].format(query=quote_plus(keyword), page=page)
        try:
            resp = requests.get(url, headers=HEADERS, timeout=REQUEST_TIMEOUT)
            resp.raise_for_status()
        except requests.RequestException as e:
            print(f"  [!] {cfg['nom_affiche']} page {page} : erreur réseau ({e})")
            break

        soup = BeautifulSoup(resp.text, "html.parser")
        cards = soup.select(sel["product_card"])
        if not cards:
            break  # plus de résultats ou sélecteur à corriger

        for card in cards:
            name_el = card.select_one(sel["name"])
            price_el = card.select_one(sel["price"])
            link_el = card.select_one(sel["link"]) or card

            if not (name_el and price_el and link_el):
                continue

            href = link_el.get("href", "")
            if href.startswith("/"):
                href = cfg["base_url"] + href

            nom = name_el.get_text(strip=True) or name_el.get("title", "")
            prix = parse_price(price_el.get_text(strip=True))

            if nom and prix and href:
                results.append({
                    "site": cfg["nom_affiche"],
                    "nom": nom,
                    "prix": prix,
                    "lien": href,
                })

        time.sleep(1)  # politesse envers le serveur

    return results


# ---------------------------------------------------------------------------
# SCRAPING VIA SELENIUM (sites JS-lourds : Zara, et fallback Marjane/Decathlon)
# ---------------------------------------------------------------------------

def get_selenium_driver(headless=True):
    from selenium import webdriver
    from selenium.webdriver.chrome.options import Options
    from selenium.webdriver.chrome.service import Service
    from webdriver_manager.chrome import ChromeDriverManager

    options = Options()
    if headless:
        options.add_argument("--headless=new")
    options.add_argument("--disable-gpu")
    options.add_argument("--no-sandbox")
    options.add_argument("--window-size=1400,2000")
    options.add_argument(f"user-agent={HEADERS['User-Agent']}")

    service = Service(ChromeDriverManager().install())
    return webdriver.Chrome(service=service, options=options)


def scrape_site_selenium(site_key, keyword, max_pages=1):
    """
    Approche en deux temps :
    1) on essaie les sélecteurs CSS configurés dans config.py
    2) si ça ne donne rien, on retombe sur une extraction "brute" :
       tous les liens <a> de la page + regex de prix dans le texte alentour.
    """
    cfg = SITES[site_key]
    sel = cfg["selectors"]
    results = []

    try:
        driver = get_selenium_driver()
    except Exception as e:
        print(f"  [!] Impossible de démarrer Selenium/Chrome pour {cfg['nom_affiche']} : {e}")
        print("      -> vérifie que Google Chrome est installé sur ta machine.")
        return results

    try:
        url = cfg["search_url"].format(query=quote_plus(keyword), page=1)
        driver.get(url)
        time.sleep(4)  # laisse le temps au JS de charger les produits

        # Scroll pour déclencher le lazy-loading des images/produits
        for _ in range(4):
            driver.execute_script("window.scrollBy(0, document.body.scrollHeight/4);")
            time.sleep(0.8)

        from bs4 import BeautifulSoup as BS
        soup = BS(driver.page_source, "html.parser")

        # --- tentative 1 : sélecteurs configurés ---
        cards = soup.select(sel["product_card"])
        for card in cards:
            name_el = card.select_one(sel["name"])
            price_el = card.select_one(sel["price"])
            link_el = card.select_one(sel["link"]) or card

            if not link_el:
                continue
            href = link_el.get("href", "")
            if href.startswith("/"):
                href = cfg["base_url"] + href

            nom = ""
            if name_el:
                nom = name_el.get_text(strip=True) or name_el.get("alt", "") or name_el.get("title", "")
            prix = parse_price(price_el.get_text(strip=True)) if price_el else None

            if nom and prix and href:
                results.append({"site": cfg["nom_affiche"], "nom": nom, "prix": prix, "lien": href})

        # --- tentative 2 (fallback) : extraction brute par regex si rien trouvé ---
        if not results:
            print(f"  [i] Sélecteurs CSS n'ont rien donné pour {cfg['nom_affiche']}, "
                  f"tentative d'extraction générique...")
            for a in soup.select("a[href]"):
                texte = a.get_text(" ", strip=True)
                prix = parse_price(texte)
                if prix and len(texte) > 5:
                    href = a.get("href", "")
                    if href.startswith("/"):
                        href = cfg["base_url"] + href
                    # le nom = texte du lien sans le prix
                    nom = texte.split(str(int(prix)))[0].strip(" -|,")
                    if not nom:
                        nom = a.get("title") or a.get("aria-label") or "Produit"
                    results.append({"site": cfg["nom_affiche"], "nom": nom, "prix": prix, "lien": href})

    finally:
        driver.quit()

    return results


# ---------------------------------------------------------------------------
# ORCHESTRATION
# ---------------------------------------------------------------------------

def scrape_all(keyword, prix_min, prix_max):
    all_results = []

    print(f"\n🔍 Recherche de '{keyword}' entre {prix_min} et {prix_max} MAD...\n")

    # Jumia : requests pur (rapide, fiable)
    print("→ Jumia Maroc...")
    all_results += scrape_site_requests("jumia", keyword)

    # Decathlon : requests d'abord, Selenium si 0 résultat
    print("→ Decathlon Maroc...")
    dec_results = scrape_site_requests("decathlon", keyword)
    if not dec_results:
        print("  [i] Pas de résultats via requests, tentative Selenium...")
        dec_results = scrape_site_selenium("decathlon", keyword)
    all_results += dec_results

    # Marjane Mall : requests d'abord, Selenium si 0 résultat
    print("→ Marjane Mall...")
    marjane_results = scrape_site_requests("marjanemall", keyword)
    if not marjane_results:
        print("  [i] Pas de résultats via requests, tentative Selenium...")
        marjane_results = scrape_site_selenium("marjanemall", keyword)
    all_results += marjane_results

    # Zara : Selenium obligatoire (SPA React)
    print("→ Zara Maroc (Selenium, peut prendre 15-30s)...")
    all_results += scrape_site_selenium("zara", keyword)

    all_results = dedupe_results(all_results)
    filtered = filter_by_price(all_results, prix_min, prix_max)
    return filtered


def main():
    keyword = input("Mot-clé produit (ex: t-shirt homme, robe femme, jean...) : ").strip()
    if not keyword:
        keyword = "t-shirt"
        print(f"Aucun mot-clé saisi, utilisation par défaut : '{keyword}'")

    try:
        prix_min = float(input("Prix minimum (MAD) : ").strip().replace(",", "."))
        prix_max = float(input("Prix maximum (MAD) : ").strip().replace(",", "."))
    except ValueError:
        print("Valeurs de prix invalides. Exemple attendu : 50")
        sys.exit(1)

    if prix_min > prix_max:
        prix_min, prix_max = prix_max, prix_min

    results = scrape_all(keyword, prix_min, prix_max)
    print_results_table(results)

    if results:
        path = export_csv(results)
        print(f"✅ Résultats exportés dans : {path}")


if __name__ == "__main__":
    main()
